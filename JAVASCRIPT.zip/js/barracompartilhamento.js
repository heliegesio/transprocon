function escreveMenuLocal(local){	
document.write('<div style="width: 612px;float:left;padding-top: 3px;"><div id="labelBarra">'+local+'</div></div><div style="float:left;padding-right:5px;padding-top: 3px;">Compartilhe</div><div style="float:left;padding-right:5px;padding-top: 1px;width: 92px;"><a href="https://twitter.com/share" class="twitter-share-button" data-url="http://goo.gl/XcK1B" data-text="Transprocon" data-via="transprocon" data-lang="pt" data-hashtags="TRANSPROCON">Tweetar</a></div><a name="fb_share"></a><script src="http://static.ak.fbcdn.net/connect.php/js/FB.Share" type="text/javascript"></script><div class="fb-like" data-href="http://www.transprocon.com.br" data-send="false" data-layout="button_count" data-width="450" data-show-faces="true"></div>');
}

!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");

escreveMenuLocal(varLocal);


