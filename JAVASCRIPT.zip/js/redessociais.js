    $(function() {
        var titlePagina = $('title').text();

                $('.shareMediaTwitter').append(
            $('<a>').attr({
                'href': 'http://twitter.com/',
                'rel': 'nofollow',
                'title': 'Compartilhe no Twitter',
                'target': '_blank'
            }).click(function() {
                window.open('http://twitter.com/intent/tweet?text='+encodeURIComponent(titlePagina + ' http://goo.gl/S6yb #TRANSPROCON')+'');
                return false;
            }).append(
                $('<img>').attr({
                     'src': "http://www.reclameaqui.com.br/images/ico-twitter.gif",
                     'alt': 'Compartilhe no Twitter'
                })
            )
        );
 
        
            });

