function escreveMenu(pagina){
	var menu1,menu2,menu3,menu4,menu5;
	if(pagina == 'home')
		menu1 = 'class="menuSelect"';
	else
		menu1 = 'class="menuUnSelect"';
	
	if(pagina == 'buscaCubo')
		menu2 = 'class="menuSelect"';
	else
		menu2 = 'class="menuUnSelect"';
	
	if(pagina == 'painelFornecedor')
		menu3 = 'class="menuSelect"';
	else
		menu3 = 'class="menuUnSelect"';
	
	if(pagina == 'ranking')
		menu4 = 'class="menuSelect"';
	else
		menu4 = 'class="menuUnSelect"';

	
document.write('<img src="../pentaho-cdf/img/toposite.jpg"><div class="menu"><div style="width:43px;cursor:pointer;"  '+menu1+'><span onclick="abreLocal(\'home\')">In&iacute;cio</span></div><div class="menuSeparador">|</div><div style="width:89px;cursor:pointer;" '+menu3+'><span onclick="abreLocal(\'painelFornecedor\')">Reclama&ccedil;&otilde;es</span></div><div class="menuSeparador">|</div><div style="width:60px;cursor:pointer;" '+menu4+'><span onclick="abreLocal(\'ranking\')">Ranking</span></div><div class="menuSeparador">|</div><div style="width:100px;cursor:pointer;" '+menu2+'><span onclick="abreLocal(\'buscaCubo\')">An&aacute;lise Avan&ccedil;ada</span></div><div class="menuSeparador"></div>'); 
}
